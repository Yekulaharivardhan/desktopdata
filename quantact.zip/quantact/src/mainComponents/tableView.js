import React, { useState,useEffect } from "react";
import { SidePanel } from "./sidePanel";
import { TopPanel } from "./topPanel";
import { Tab, Tabs } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import { DataTable } from "../components/DataTable";
import Dropzone from "react-dropzone";
import axios from "axios";
export const TableView = () => {
  const [key, setKey] = useState("ALL");
  const location = useLocation();
  var finalData = location.state.result;
  var [dup, setDup] = useState([]);
  var [dupArr, setDupArr] = useState([]);
  const [flag, setFlag] = useState(true);
  var [finalData, setFinalData] = useState(finalData);
  const [finalArray, setFinalArray] = useState([]);
  const [newArray, setNewArray] = useState([]);
  const [dupArray, setDupArray] = useState([]);
  const [dupData, setDupData] = useState([]);
  var arr = new Array();
  var [column, setColumn] = useState(location.state.columns);
  useEffect(() => {
    setDup(dups);
    setDupArr(dupArrays);
    
  }, [dups, dupArrays]);

  var flags;
  const re =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  finalData.map((r, i) => {
    Object.entries(r).map(item => {
      // console.log(item[1])
      if(re.test(item[1])){
         flags = item[0]
        
      }
      return false
    })
}); 

  const removeDuplicates = (array) => {
    let uniq = {};
    return array.filter(
      (obj) => !uniq[obj[flags]] && (uniq[obj[flags]] = true)
    );
  };
  const returnUnique = (itemsCollection) => {
    const itemsMap = new Map();
    itemsCollection.forEach((item) => {
      if (itemsMap.size === 0) {
        itemsMap.set(item.Header, item);
      } else if (!itemsMap.has(item.Header)) {
        itemsMap.set(item.Header, item);
      }
    });
    return [...new Set(itemsMap.values())];
  };
  if (finalData != null) {
   
    for (let i = 0; i < finalData.length; i++) {
      if (!re.test(finalData[i][flags])) {
        arr.push(finalData[i]);
      }
    }
  
    var duplicate = finalData
      .map((e) => e[flags])
      .map((e, i, finalData) => finalData.indexOf(e) !== i && i)
      .filter((obj) => finalData[obj])
      .map((e) => finalData[e]);
  
    var dups = removeDuplicates(duplicate);
  
    const lookup = finalData.reduce((a, e) => {
      a.set(e[flags], (a.get(e[flags]) ?? 0) + 1);
      return a;
    }, new Map());
    var dupArrs = finalData.filter((e) => lookup.get(e[flags]) > 1);
  //     const sortedArr = dupArrs.sort((a, b) => a[flag] - b[flag]);
  
  
   const sorted_by_name = dupArrs.sort((a, b) => {
      return a[flags].localeCompare(b[flags])
   });
  
    localStorage.setItem("dupArrayData", JSON.stringify(sorted_by_name));
    var dupArrays = JSON.parse(localStorage.getItem("dupArrayData"));
  }
  const onDropFile = async (file) => {
    var files = JSON.parse(localStorage.getItem("filenames"));
     var finalUnique;
    var d1;
    var new_file_name;
    setFlag(false);
    const name = file[0].name;
    const ext = name.split(".")[1];
    var url;
    if (window.location.hostname === "localhost") {
      url = "http://localhost:3000/csvtojson";
    } else {
      url = "https://dev.quantact.ai/backend/csvtojson";
    }
    let formData = new FormData();
    formData.append("file", file[0]);
  
    if (ext == "csv") {
      await axios.post(url + "/save_file", formData).then(async (res) => {
        new_file_name = res.data.result[0].file_details[0].file_name;

        files.push(new_file_name);
        localStorage.setItem("filenames", JSON.stringify(files));
        await axios
          .post(url + "/column_row_merge", { filename: files })
          .then((response) => {
            response = response.data.result;
            var result = response.filter((item) => {
              return delete item._id, delete item.file_details, delete item.quantana_workspace_id, delete item.quantana_company_id ,delete item.quantana_list_id;
            });
            d1 = result;
          });
       
       
        var arr2 = new Array();
        var flag;
        if (d1 != null) {
         
          const re =
            /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          for (let i = 0; i < d1.length; i++) {
            if (!re.test(d1[i][flags])) {
              arr = [];
              arr2.push(d1[i]);
            }
          }
        }
        var duplicate = d1
        .map((e) => e[flags])
        .map((e, i, d1) => d1.indexOf(e) !== i && i)
        .filter((obj) => d1[obj])
        .map((e) => d1[e]);
  
      var dups = removeDuplicates(duplicate);
  
      const lookup = d1.reduce((a, e) => {
        a.set(e[flags], (a.get(e[flags]) ?? 0) + 1);
        return a;
      }, new Map());
      var dupArrs = d1.filter((e) => lookup.get(e[flags]) > 1);
 
     const sorted_by_name = dupArrs.sort((a, b) => {
        return a[flags].localeCompare(b[flags])
     });
     console.log(column)
     setDup(dups);
     setDupArr(sorted_by_name);
     setNewArray(arr2);
        console.log(d1)
        if (d1 != null) {
          for (let i = 0; i < Object.keys(d1[0]).length; i++) {
            let obj = {
              Header: Object.keys(d1[0])[i].toLocaleUpperCase(),
              accessor: Object.keys(d1[0])[i],
            };
            column.push(obj);
          }
        }
      
        var uniqueCols = returnUnique(column);
          // setFinalArray(finalUnique);
        // setEditedFinalArray(finalUnique);
        // setEditedExtraArray(finalUnique);
        // localStorage.setItem("final", JSON.stringify(finalUnique));
        setColumn(uniqueCols);
        // setColumn(column);
        setFinalArray(d1);
        // setEditedFinalArray(d1);
        // setEditedExtraArray(d1);
        localStorage.setItem("final", JSON.stringify(d1));
      });
    }
  };
  const addClass = (e) => {
    if (e) {
      console.log(document.getElementById("dragarea").classList)
      if (
        document
          .getElementById("dragarea")
          .classList.contains("dragndrop-overlay")
      ) {
        document
          .getElementById("dragarea")
          .classList.remove("dragndrop-overlay");
        document.getElementById("dragarea").classList.add("dragLeave");
      } else {
        document.getElementById("dragarea").classList.add("dragLeave");
      }
    }
  };
  const leaveClass = (e) => {
    console.log('hi',document.getElementById("dragarea").classList)
    if (e) {
      if (document.getElementById("dragarea").classList.contains("dragLeave")) {
        document.getElementById("dragarea").classList.remove("dragLeave");
        document.getElementById("dragarea").classList.add("dragndrop-overlay");
      } else {
        document.getElementById("dragarea").classList.add("dragndrop-overlay");
      }
    }
  };
  return (
    <>
      <div className="d-flex">
        <SidePanel />

        <div>
          <TopPanel />
          <div>
            <Dropzone
              onDrop={onDropFile}
              multiple={false}
              noClick={true}
              style={{ cursor: "none" }}
            >
              {({ getRootProps, getInputProps }) => (
                <section>
                  <div {...getRootProps()} role="none">
                    {flag ? (
                      <>
                         <div
                          {...getRootProps}
                          id="dragarea"
                          role="none"
                          onDrop={(event) => addClass(event)}
                          onDragOver={(e) => leaveClass(e)}
                        >
                        <Tabs
                id="controlled-tab-example"
                activeKey={key}
                onSelect={(k) => setKey(k)}
                className="my-2"
              >
                <Tab
                  eventKey="ALL"
                  title={`All ${finalData ? finalData.length : ""}`}
                  className="Active"
                >

                  <DataTable
                    tab="All"
                    data={finalData}
                    columns={column}
                 
                  ></DataTable>
                </Tab>
                <Tab
                  eventKey="ERRORS"
                  title={`Errors ${arr.length}`}
                >
                  <DataTable
                    tab="Errors"
                    data={arr}
                    columns={column}
                 
                  ></DataTable>
                </Tab>
                <Tab
                  eventKey="DUPLICATE"
                  title={`Duplicate ${dup
                      ? dup.length
                      : dupArray
                        ? dupArray.length
                        : ""
                    }`}
                >
                  <DataTable
                    tab="Duplicate"
                    data={dupArr ? dupArr : dupData}
                    columns={column}
              
                  ></DataTable>
                </Tab>

                <Tab
                  eventKey="Suggestions"
                  title={`Suggestions ${dup
                      ? dup.length
                      : dupArray
                        ? dupArray.length
                        : ""
                    }`}
                >
                  <DataTable
                    tab="Suggestions"
                    data={dupArr ? dupArr : dupData}
                    columns={column}
                 
                  ></DataTable>
                </Tab>
              </Tabs>
              </div>
                       
                      </>
                    ) : (
                      <>
                        <div
                          {...getRootProps}
                          id="dragarea"
                          role="none"
                          onDrop={(event) => addClass(event)}
                          onDragOver={(e) => leaveClass(e)}
                        >
                        <Tabs
                id="controlled-tab-example"
                activeKey={key}
                onSelect={(k) => setKey(k)}
                className="my-2"
              >
                <Tab
                  eventKey="ALL"
                  title={`All ${finalArray.length}`}
                  className="Active"
                >

                  <DataTable
                    tab="All"
                    data={finalArray}
                    columns={column}
                 
                  ></DataTable>
                </Tab>
                <Tab
                  eventKey="ERRORS"
                  title={`Errors ${newArray.length}`}
                >
                  <DataTable
                    tab="Errors"
                    data={newArray}
                    columns={column}
                 
                  ></DataTable>
                </Tab>
                <Tab
                  eventKey="DUPLICATE"
                  title={`Duplicate ${
                    dup
                      ? dup.length
                      : dupArray
                      ? dupArray.length
                      : ""
                  }`}
                >
                  <DataTable
                    tab="Duplicate"
                    data={dupArr ? dupArr : dupData}
                    columns={column}
              
                  ></DataTable>
                </Tab>

                <Tab
                  eventKey="Suggestions"
                  title={`Suggestions ${dup
                      ? dup.length
                      : dupArray
                        ? dupArray.length
                        : ""
                    }`}
                >
                  <DataTable
                    tab="Suggestions"
                    data={dupArr ? dupArr : dupData}
                    columns={column}
                 
                  ></DataTable>
                </Tab>
              </Tabs>
                        </div>
                      </>
                    )}
                  </div>
                </section>
              )}
            </Dropzone>
          </div>
        </div>
      </div>
    </>
  )
}