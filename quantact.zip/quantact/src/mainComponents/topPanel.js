import React from "react"


export const TopPanel = () =>{
return(
    <>
    <div className="top-panel p-1">
    <h5>
        <span className="float-start p-3">Recents</span>
                        <span className="float-end pe-2">
                        <select className="qdropdown">
        <option value="Quantana">Quantana</option>
        <option value="Quantana">Quantana</option>
    </select>
    <img  src="/images/notification.svg"
                    width="30px"
                    height="30px"></img>
  
   
    <img  src="/images/profile-pic.svg"
                    width="50px"
                    height="50px"></img>
                            </span>
                    </h5>
    </div>

 
     


       
     {/* <div className="top-panel d-flex justify-content-end">
        <div className="d-inline-flex p-2">
     <h4>Recents</h4>
     </div>
 
    <select className="qdropdown">
        <option value="Quantana">Quantana</option>
        <option value="Quantana">Quantana</option>
    </select>
    <img  src="/images/notification.svg"
                    width="30px"
                    height="30px"></img>
  
   
    <img  src="/images/profile-pic.svg"
                    width="50px"
                    height="50px"></img>
  
     </div> */}
  

    <hr className="topBarDivider"></hr>
    </>
)
}