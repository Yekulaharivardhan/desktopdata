import React ,{ useState} from "react";
import { SidePanel } from "./sidePanel";
import { TopPanel } from "./topPanel";
import Dropzone from "react-dropzone";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";

import Modal from 'react-bootstrap/Modal';

export const  IntroPanel =() =>{
    const [flag, setFlag] = useState();
    const [show, setShow] = useState(false);
  const [file,setFile] =useState()
  const onSave = () => {
   
    setShow(false);
    // if(!saveChanges){
      const name = file[0].name;
  
      const ext = name.split(".")[1];
      var url;
      if (window.location.hostname === "localhost") {
        url = "http://localhost:3000/csvtojson";
      } else {
        url = "https://dev.quantact.ai/backend/csvtojson";
      }
      let formData = new FormData();
      // var loginData = JSON.parse(localStorage.getItem("result"));
      // console.log("loginData", loginData);
      formData.append("file", file[0]);
      // formData.append("workspace_id", loginData.lists[0].workspace_id);
      // formData.append("list_id", loginData.lists[0]._id);
      // formData.append("company_id", loginData.lists[0].company_id);
      if (ext == "csv") {
        axios
          .post(url + "/save_file", formData)
          .then((res) => {
            var fileName = res.data.result[0].file_details[0].file_name;
            localStorage.setItem("filenames", JSON.stringify([fileName]));
            localStorage.setItem("dataWithId", JSON.stringify(res.data.result));
  
            var result = res.data.result.filter((item) => {
              return (
                delete item._id,
                delete item.file_details,
                delete item.quantana_workspace_id,
                delete item.quantana_company_id,
                delete item.quantana_list_id
              );
            });
  
            localStorage.setItem("final", JSON.stringify(result));
  
            const COLUMNS = [];
            if (result != null) {
              for (let i = 0; i < Object.keys(result[0]).length; i++) {
                let obj = {
                  Header: Object.keys(result[0])[i].toLocaleUpperCase(),
                  accessor: Object.keys(result[0])[i],
                };
                COLUMNS.push(obj);
              }
            }
            console.log("result", result);
            localStorage.setItem("columns",JSON.stringify(COLUMNS))
            // setTimeout(navigate("/Table"),10000)
            navigate("/TableView",{state:{result:result,columns:COLUMNS}});
          })
          .catch((error) => {
            console.log("error", error);
          });
      }

  }
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  const navigate = useNavigate();
    const onDrop = (file) => {
      handleShow()
      setFile(file)
      };
return(
    <>
    <div className="d-flex"> 
    <SidePanel /> 
   
        <div>
        <TopPanel />
        <div>
            <div className="contacts-files-filters">
                <div  className="float-end" style={{    marginTop: "-20px",}}>
<select className="dropdown ms-2">
    <option value="contacts">contacts</option>
    <option value="contacts">contacts</option>
</select>
<select className="dropdown ms-2">
    <option value="filters">filters</option>
    <option value="filters">filters</option>
</select></div>

            </div>
            <div >
            <Dropzone onDrop={onDrop} multiple={false} >
            {({ getRootProps, getInputProps }) => (
              <section>
                <div
                  {...getRootProps(
                    !flag ? { className: "csvfile-class" } : { className: "" }
                  )}
                ><div  className="text-center row">
                     <div className="col-3"></div>
                    <div className="col-1">
                  <img  className="me-2"
                    src="/images/upload-cloud.svg"
                    width="50px"
                    height="50px"
                  ></img>
                  </div>
                  <div className="col-4">
                 <h5>Select a file or drag and drop here</h5>
                 <p className="new-gray">CSV, XLS or XLSX, or any other similar files</p>
                 </div>
                 <div className="col-2 text-center">
                 <button className="upload-button">SELECT FILE</button>
                 </div>
                 <div className="col-2"></div>
                  <input {...getInputProps()} />
                  </div> 
                </div>
              </section>
            )}
          </Dropzone>
</div>
            <div>

            </div>
        </div>
        <div>
        <div className="last-edited">
            <p className="m-0 new-gray">Last edited</p>
         </div>
         <div className="last-edit-table">
         <h5>Latest Activity</h5>
         <p className="new-gray">Nothing's happened yet!
All your recent files history will be shown here</p>
         </div>
        </div>
        </div>
      
    </div>
    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>List properties</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div><p><span className="float-start">Adding to the List</span>
          <span className="float-end">Add as new <input type="checkbox"></input></span>
          </p></div>
          <br></br>
          <div>
          <select className="qdropdown form-control">
        <option value="Contacts">Contacts</option>
        <option value="Contacts">Contacts</option>
    </select>
          </div>
          <hr></hr>
          <div>
            <label>Tags</label>
            <input type="text" className="form-control" placeholder="Search tags"></input>
            <br></br>
            <textarea placeholder="Enter new tags" className="form-control"></textarea>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button id="close" className="btn btn-outline-secondary" onClick={handleClose}>
            Close
          </button>
          <button className="upload-button" onClick={onSave}>
            Save and Proceed
          </button>
        </Modal.Footer>
      </Modal>
    </>
)
}