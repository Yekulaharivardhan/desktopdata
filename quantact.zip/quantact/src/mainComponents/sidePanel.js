
import React from "react";
export const  SidePanel = () =>
{ 
return(
    
    <>
    <div>
    <div className="logo-section">
   
     <img src="/images/quantact-main-logo.svg"></img> &nbsp;
     <h3>QUANTACT</h3>
     </div>

    <hr className="divider-class"></hr>
    <div className="sideBar">
    <ul className="list-group list-group-flush nav_list" id="menu">
       <li className="pb-3 pt-1 my-2 border-0"><a >
       <span className="ps-1" ><img src="/images/recents.svg"></img></span> Recent
       
        </a></li>
      {/* <li  className="pb-3 pt-1 my-2 border-0">
        <button id="hamburger" class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="true">
          Home
        </button>
        <div className="collapse show" id="home-collapse">
          <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
          <li><a href="#home">All</a></li>
          <li><a href="#about">Contacts</a></li>
          <li><a href="#donate">List 2</a></li>
          <li><a href="#download">List 3</a></li>
          </ul>
        </div>
      </li> */}
     
    <li className="pb-3 pt-1 my-2 border-0"><a><span className="ps-1" ><img src="/images/list.svg"></img></span>List</a>
        <ul id="list">
        <li><a href="#home">All</a></li>
          <li><a href="#about">Contacts</a></li>
          <li><a href="#donate">List 2</a></li>
          <li><a href="#download">List 3</a></li>
        </ul>
    </li>
        <li className="pb-3 pt-1 my-2 border-0"><a >
       <span className="ps-1" >
        <img src="/images/team.svg"></img></span> Team
       
        </a></li>
        <li className="pb-3 pt-1 my-2 border-0"><a >
       <span className="ps-1" >
        <img src="/images/audience.svg"></img></span> Audience
       
        </a></li>
     </ul>
    </div>
    </div>
    </>
)
}