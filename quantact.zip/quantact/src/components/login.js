import { useNavigate, useLocation } from "react-router-dom";
import React, { useState } from "react";
import validator from 'validator'
import axios from "axios";
import { Tab, Tabs } from "react-bootstrap";
import { app } from './firbaseConfig';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth'
import {ToastContainer,toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const Login = () => {
  // toast.configure()
  const navigate = useNavigate();
  const [emailError, setEmailError] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [signUpEmailError, setSignUpEmailError] = useState('')
  const [passwordMessage, setPasswordMessage] = useState('')
  const [key, setKey] = useState("Login");
  
  const loginRedirect = () => {
    var url,result;
   var email = document.getElementById('email').value
   var password = document.getElementById('password').value
   if(validator.isEmail(email) && validator.isStrongPassword(password, {
    minLength: 8, minLowercase: 1,
    minUppercase: 1, minNumbers: 1, minSymbols: 1
  })){
    const authentication = getAuth();
    signInWithEmailAndPassword(authentication, email, password)
    .then((response) => {
   
    if (window.location.hostname === "localhost") {
      url = "http://localhost:3000/users";
    } else {
      url = "https://dev.quantact.ai/backend/users";
    }
    axios
      .post(url + "/login", {"email":email})
      .then((res) => {
        if(res.status == 200){
          result = res.data
          localStorage.setItem('result', JSON.stringify(result))
          // console.log('result',result.token)
          localStorage.setItem('refreshToken',result.refreshtoken)
          localStorage.setItem('token',result.token)
          navigate("/CsvImport");
          localStorage.setItem('Auth Token', response._tokenResponse.refreshToken)
        }
       
      })
     
    }).catch(error => {
      // console.log(error.response.data)
 
        var errorCode = error.code;
        console.log(error.message, errorCode)
        if(errorCode == "auth/weak-password"){
          toast.error("Password too weak")
        }
        else if(errorCode == "auth/email-already-in-use"){
          toast.error("Email already exists")
        }else if(errorCode == 'auth/wrong-password'){
          toast.error('Please check the Password');
        }else if(errorCode == 'auth/network-request-failed'){
          toast.error('Please check the Connection');
        }
      })

  }
    
  };
  
  const validateEmail = (e) => {
    var email = e.target.value
  
    if (validator.isEmail(email)) {
      setEmailError('')
    } else {
      setEmailError('Enter valid Email!')
    }
  }
 
  const validate = (value) => {
    
    if (validator.isStrongPassword(value, {
      minLength: 8, minLowercase: 1,
      minUppercase: 1, minNumbers: 1, minSymbols: 1
    })) {
      setErrorMessage('')
    } 
     else {
      setErrorMessage('It should contain atleast 1 number, 1 spacial character, 1 lowercase, 1 uppercase with length 8 ')
    }
  }
  const signUpRedirect = () =>{
    var url,result;
    var email = document.getElementById('signUpEmail').value
    var password = document.getElementById('signUpPassword').value
    var company = document.getElementById('company').value
    if((validator.isEmail(email) && validator.isStrongPassword(password, {
     minLength: 8, minLowercase: 1,
     minUppercase: 1, minNumbers: 1, minSymbols: 1
   })) && company != null ){
    const authentication = getAuth();
  
      createUserWithEmailAndPassword(authentication, email, password)
      .then((response) => {
    
    if (window.location.hostname === "localhost") {
      url = "http://localhost:3000/users";
    } else {
      url = "https://dev.quantact.ai/backend/users";
    }
    axios
      .post(url + "/signup", {"email":email,"company":company})
      .then((res) => {
        if(res.status == 200){
          result = res.data
          
          localStorage.setItem('result', JSON.stringify(result))
        localStorage.setItem('Auth Token', response._tokenResponse.refreshToken)
       
        navigate("/CsvImport");
      }

        })
      }).catch(error => {
   
   
          var errorCode = error.code;
          console.log(error.message, errorCode)
          if(errorCode == "auth/weak-password"){
            toast.error("Password too weak")
          }
          else if(errorCode == "auth/email-already-in-use"){
            toast.error("Email already exists")
          }else if(errorCode == 'auth/wrong-password'){
            toast.error('Please check the Password');
          }else if(errorCode == 'auth/too-many-requests'){
            toast.error("Access to this account has been temporarily disabled due to many failed login attempts")
          }else if(errorCode == 'auth/network-request-failed'){
            toast.error('Please check the Connection');
          }
        })
          // else{
          //   //If succsess
          //   firebase.auth().sendSignInLinkToEmail(email, actionCodeSettings).then(() => {
          //     window.localStorage.setItem('emailForSignIn', email);
          //   }).catch((error) => {
          //     var errorCode = error.code;
          //     var errorMessage = error.message;
          //   });
          // }
   
    
      
      // toast.error('Runtime error')
      //   .then((response) => {
      //     console.log('response',response)
      //     sessionStorage.setItem('Auth Token', response._tokenResponse.refreshToken)
         
      //     navigate("/CsvImport");
       
      //   }).catch(error => {
      //     console.log(error.response.data)
      //  })
    // }

   }
  }
  const validateSignUpEmail =(e)=>{
    var email = e.target.value
  
    if (validator.isEmail(email)) {
      setSignUpEmailError('')
    } else {
      setSignUpEmailError('Enter valid Email!')
    }
  }
  const validateSignUpPassword = (e)=>{
    if (validator.isStrongPassword(e, {
      minLength: 8, minLowercase: 1,
      minUppercase: 1, minNumbers: 1, minSymbols: 1
    })) {
      setPasswordMessage('')
    } 
     else {
      setPasswordMessage('It should contain atleast 1 number, 1 spacial character, 1 lowercase, 1 uppercase with length 8 ')
    }
  }
  return (
    <>
      <div className="row m-0">
        <div className="col-lg-5 col-sm-5 p-0">
          <div id="login_left" className="px-5 py-4"></div>
        </div>
        <div className="col-lg-7 col-sm-7 bg-white">
          <div id="login_div" style={{marginTop: "-60px"}}>
         
            <div className="row justify-content-center" id="form_div">
            <div className="col-xl-6 col-md-8 col-11">
            <Tabs
                            id="controlled-tab-example"
                            activeKey={key}
                            onSelect={(k) => setKey(k)}
                         
                          > 
                         
                          <Tab eventKey="Login"
                           title="Login"
                           className="Active">
               <br></br>
                <h2>Login</h2>
                <br></br>
                <label>Email<span style={{color: 'red',}}>*</span> </label>
                <input
                  type="email"
                  id="email"
                  placeholder="Enter your Email"
                  className="form-control"
                  onChange={(e) => validateEmail(e)}
                ></input>
                <span style={{
         
          color: 'red',
        }}>{emailError}</span>
         <br></br>
                <label>Password<span style={{ color: 'red', }}>*</span> </label>
                  <input
                    autoComplete="new-password"
                    id="password"
                    className="form-control"
                    placeholder="Enter Password"
                    type="password"
          // onChange={(e) => validate(e.target.value)}
                    required
                  />
                   <span style={{
       
          color: 'red',
        }}>{errorMessage}</span>
                  <br></br>
               
                <button
                  type="submit"
                  className="btn btn-lg btn-outline-secondary col-12 mt-2"
                  onClick={loginRedirect}
                >
                  Login
                </button>
                <ToastContainer />
              
              </Tab>
              <Tab eventKey="Signup"  title="Sign Up">
              <br></br>
                <h2>Sign Up</h2>
                <br></br>
                <label>Email<span style={{color: 'red',}}>*</span> </label>
                <input
                  type="email"
                  id="signUpEmail"
                  placeholder="Enter your Email"
                  className="form-control"
                  onChange={(e) => validateSignUpEmail(e)}
                ></input>
                <span style={{
         
          color: 'red',
        }}>{signUpEmailError}</span>
         <br></br>
                <label>Password<span style={{ color: 'red', }}>*</span> </label>
                  <input
                    autoComplete="new-password"
                    id="signUpPassword"
                    className="form-control"
                    placeholder="Enter Password"
                    type="password"
          onChange={(e) => validateSignUpPassword(e.target.value)}
                    required
                  />
                   <span style={{
       
          color: 'red',
        }}>{passwordMessage}</span>
                  <br></br>
                  <label>Company<span style={{ color: 'red', }}>*</span> </label>
                  <input
                    id="company"
                    className="form-control"
                    placeholder="Enter Company"
                    type="text"
        //   onChange={(e) => validate(e.target.value)}
                    required
                  />
                 
                  <br></br>
               
                <button
                  type="submit"
                  className="btn btn-lg btn-outline-secondary col-12 mt-2"
                  onClick={signUpRedirect}
                >
                  Sign Up
                </button>
                <ToastContainer />
              </Tab>
            </Tabs>
            </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
