import Dropzone from "react-dropzone";

import { Topbar } from "./Topbar";
import { Sidebar } from "./Sidebar";
import { useNavigate, useLocation } from "react-router-dom";

import React, { useState, CSSProperties } from "react";
import axios from "axios";
import {
  useCSVReader,
  lightenDarkenColor,
  formatFileSize,
  usePapaParse,
} from "react-papaparse";


export const CsvImport = () => {

  const navigate = useNavigate();
  const { CSVReader } = useCSVReader();
  const { readString } = usePapaParse();
  const { jsonToCSV } = usePapaParse();
  const [zoneHover, setZoneHover] = useState(false);
  const [flag, setFlag] = useState();
  const [generate, setGenerate] = useState(false);
  
 

const onDrop = (file) =>{
  const name= file[0].name
 
  const ext=name.split('.')[1]
  var url;
  if (window.location.hostname === 'localhost') {
    url= 'http://localhost:3000/csvtojson'
} else {
   url = "https://dev.quantact.ai/backend/csvtojson"
}
let formData = new FormData();
var loginData = JSON.parse(localStorage.getItem('result'))
console.log('loginData',loginData)
formData.append("file", file[0]);
formData.append("workspace_id",loginData.lists[0].workspace_id)
formData.append("list_id",loginData.lists[0]._id)
formData.append("company_id",loginData.lists[0].company_id)
  if(ext == "csv"){
    axios.post(url+'/save_file',formData
    ).then(res=>{
 var fileName=  res.data.result[0].file_details[0].file_name
 localStorage.setItem('filenames',JSON.stringify([fileName]))
localStorage.setItem('dataWithId',JSON.stringify(res.data.result))

var result = res.data.result.filter(item=>{
 return delete item._id,delete item.file_details, delete item.quantana_workspace_id, delete item.quantana_company_id ,delete item.quantana_list_id;
})

localStorage.setItem("final", JSON.stringify(result));

const COLUMNS = [];
if (result != null) {
  for (let i = 0; i < Object.keys(result[0]).length; i++) {
    let obj = {
      Header: Object.keys(result[0])[i].toLocaleUpperCase(),
      accessor: Object.keys(result[0])[i],
    };
    COLUMNS.push(obj);
  }
}

console.log('result',result)
// localStorage.setItem("columns",JSON.stringify(COLUMNS))
// setTimeout(navigate("/Table"),10000)
setTimeout(navigate("/Table",{state:{result:result,columns:COLUMNS}}),10000); 
    }).catch((error) => {
      console.log('error',error)
    });
  }
}
  // const setImportFile = (file) => {
  //   setFlag(true);
  //   handleFile(file);
  // };
 
  return (
    <>
      <div className="App">
     
        {/* <Sidebar /> */}

        <div >
          {/* <Topbar /> */}
          <div>
          
          <Dropzone onDrop={onDrop}  multiple={false}>
          {({ getRootProps, getInputProps }) => (
              <section>
                <div>
                <h5 style={{marginTop:"-530px",textAlign:"center"}}>Welcome to Quantact, get started below</h5>
                </div>
              
                 <div {...getRootProps(!flag?{ className: "dropzone" }: { className: "" })}>
                 
                 <img
                          src="/images/dragdrop.svg"
                          width="250px"
                          height="250px"
                        ></img>
                      
                        <p className="pt-4 text1">
                          <span>Drag & Drop one or more CSV files here</span>
                       
                        </p>
                        <p className="text">
                           csv types are supported.
                        </p>
                   <input {...getInputProps()} /> 
                 </div>
                 <p className="text2">OR</p>
                      <div >
                        <button 
                          type="button"
                          {...getRootProps()}
                          className="btntext"
                        //  onClick={onDrop}
                        >
                          Import Files
                        </button>
                      </div>
              </section>

          )}
        </Dropzone>
       
            {/* <div className="dropzone">
            <img
                          src="/images/dragdrop.svg"
                          width="250px"
                          height="250px"
                        ></img>
                      
                        <p className="pt-4 text1">
                          <span>Drag & Drop one or more CSV files here</span>
                       
                        </p>
                        <p className="text">
                           Csv types are supported.
                        </p>
            <input type="file" style={{"position": "absolute","top":"20px"}}></input>
            </div> */}
            
          </div>
         {/* <div >
          <CSVReader 
            onUploadAccepted={(file) => handleFile(file)}
            onDragOver={(event) => {
              event.preventDefault();
              setZoneHover(true);
            }}
            onDragLeave={(event) => {
              event.preventDefault();
              setZoneHover(false);
            }}
            noClick
          >
            {({
              getRootProps,
              acceptedFile,
              ProgressBar,
              getRemoveFileProps,
              Remove,
            }) => (
              <>
                <div {...getRootProps()}>
                  {acceptedFile ? (
                    <>
                    <div></div>
                     
                  
                    </>
                  ) : (
                    !flag && (
                      <div className="dropzone">
                        <img
                          src="/images/dragdrop.svg"
                          width="250px"
                          height="250px"
                        ></img>
                      
                        <p className="pt-4 text1">
                          <span>Drag & Drop one or more CSV files here</span>
                       
                        </p>
                        <p className="text">
                           Csv types are supported.
                        </p>
                      </div>
                    )
                  )}
                </div>
              </>
            )}
          </CSVReader>
          {!zoneHover && (
            <CSVReader onUploadAccepted={(file) => setImportFile(file)}>
              {({
                getRootProps,
                acceptedFile,
                ProgressBar,
                Remove,
                getRemoveFileProps,
              }) => (
                <>
                  {!flag && (
                    <span>
                      <p className="text2">OR</p>
                      <div >
                        <button 
                          type="button"
                          {...getRootProps()}
                          className="btntext"
                        >
                          Import Files
                        </button>
                      </div>
                    </span>
                  )}
                  {acceptedFile && (
                    <div></div>
                    
                  )}
                
                </>
              )}
            </CSVReader>
          )}
          </div> */}
        </div>
      </div>
    </>
  );
};
