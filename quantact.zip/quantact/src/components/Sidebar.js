import React from "react";
import { HashRouter, Route, Link, Routes } from "react-router-dom";
export const Sidebar = () => {
  // console.log(JSON.parse(localStorage.getItem('result')))
  if(JSON.parse(localStorage.getItem('result')) != null){
    

  if(JSON.parse(localStorage.getItem('result')).message == "login successfull"){
    var sidebarLists = JSON.parse(localStorage.getItem('result')).lists
    var sidebarWorkspaces = JSON.parse(localStorage.getItem('result')).workspaces
    console.log('sidebarContent',sidebarWorkspaces)
  }else {
     sidebarLists = JSON.parse(localStorage.getItem('result')).list
     sidebarWorkspaces = JSON.parse(localStorage.getItem('result')).workspace
     
  }
}
  
  const changeSideBar = () =>{
      
      document.getElementById("side_bar").style.width = "200px";
      document.getElementById("side_bar").style.textAlign = "left"
      var element= document.getElementById("workspace")
      var listElement =document.getElementById('lists')
      var borderClassElement =document.getElementById("white-border")
      var listItem =document.getElementById("sidebar-list")
      // console.log('sidebarContent',sidebarWorkspaces,sidebarLists)
   sidebarWorkspaces.map(item=>{
     return(
       element.innerHTML=item.name,
      //  borderClassElement.classList.add("border-class"),
       element.style.color="#19bdcb"
     )
   }
   )
   sidebarLists.map(item=>{
    return(
      listElement.innerHTML=item.name,
      // borderClassElement.classList.remove("border-class"),
      // listItem.classList.add('border-class'),
     listElement.style.color="white"
      
    )
   })
  }
  const changeOldSideBar =() =>{
    document.getElementById("side_bar").style.width = "62px";
    document.getElementById("side_bar").style.textAlign = "center"
    var element= document.getElementById("workspace")
  var listElement =document.getElementById('lists')
    element.innerHTML=""
    listElement.innerHTML = ""
  }
  return (
    <div id="side_bar" className="sidebar" onMouseEnter={changeSideBar}  onMouseLeave={changeOldSideBar}>
      {/* <div className="pb-5 pt-3">
        <img src="/images/logo.svg" alt="logo"></img>
      </div>
      <div className="pt-3 pb-3 border-class">
        <img src="/images/file.svg" alt="file"></img>
      </div>
      <div className="pt-3">
        <img src="/images/settings.svg" alt="settings"></img>
  </div> */}

            <ul className="list-group list-group-flush nav_list">

               
              
                    <li className="pb-5 pt-1 my-2 border-0">
                        <span ><img src="/images/logo.svg"/></span>
                        <span className="d-none"><img src="/images/logo.svg"/></span>
                                        
                    </li>

                   
                <Link to="/" style={{textDecoration:"none"}}>
                    <li  className="border-0 pt-3 pb-3 border-class" id="white-border">
                     
                        <span className="ps-1" ><img src="/images/file.svg"/><span id="workspace" className="ps-1">
                          </span> </span>
                       
                      
                    </li>
                    <li id="sidebar-list"> <br></br>
                        <span id="lists" className="ps-4 pt-1"></span></li>
                    </Link>
              <Link to="/Table">
                    <li className="my-2 border-0 pt-3">
                        <span  className="ps-1"  ><img  src="/images/settings.svg"/></span>
                       
                      
                    </li>
                    </Link>
                 


            </ul>

        </div>
   
  );
};
