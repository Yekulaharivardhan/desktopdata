const finalData = JSON.parse(localStorage.getItem("final"));
export const COLUMNS=[]
if(finalData != null){
  console.log('finalData',finalData[0],Object.keys(finalData[0]).length)
  console.log('jjjjjjjjj',Object.keys(finalData[0])[0])

  
  for(let i=0; i <Object.keys(finalData[0]).length; i++)
  {
     let obj={
      Header: Object.keys(finalData[0])[i].toLocaleUpperCase(),
      accessor: Object.keys(finalData[0])[i],
     }
     COLUMNS.push(obj)
  }
}


// console.log('COL',COL)
// export const COLUMNS = [
//   {
//     Header: "COMPANY",
//     accessor: "company",
 
//   },
//   {
//     Header: "PERSON",
//     accessor: "person",
//   },
//   {
//     Header: "EMAIL",
//     accessor: "email",
   
//   },
//   {
//     Header: "PHONE",
//     accessor: "phone",
//   },
//   {
//     Header: "DATE",
//     accessor: "date",
//   },
//   {
//     Header: "LOCATION",
//     accessor: "location",
//   },
//   {
//     Header: "TAG",
//     accessor: "tag",
//   },
//   {
//     Header:"ERROR",
//     accessor:"error"
//   }
// ];
console.log('Cooooooo',COLUMNS)