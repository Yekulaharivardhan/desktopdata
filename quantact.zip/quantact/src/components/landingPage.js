import React, { useState } from "react";
import { Nav } from "react-bootstrap";
import Dropzone from "react-dropzone";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
export const LandingPage = () => {
  const [flag, setFlag] = useState();
  const navigate = useNavigate();
  const onDrop = (file) => {
    const name = file[0].name;

    const ext = name.split(".")[1];
    var url;
    if (window.location.hostname === "localhost") {
      url = "http://localhost:3000/csvtojson";
    } else {
      url = "https://dev.quantact.ai/backend/csvtojson";
    }
    let formData = new FormData();
    // var loginData = JSON.parse(localStorage.getItem("result"));
    // console.log("loginData", loginData);
    formData.append("file", file[0]);
    // formData.append("workspace_id", loginData.lists[0].workspace_id);
    // formData.append("list_id", loginData.lists[0]._id);
    // formData.append("company_id", loginData.lists[0].company_id);
    if (ext == "csv") {
      axios
        .post(url + "/save_file", formData)
        .then((res) => {
          var fileName = res.data.result[0].file_details[0].file_name;
          localStorage.setItem("filenames", JSON.stringify([fileName]));
          localStorage.setItem("dataWithId", JSON.stringify(res.data.result));

          var result = res.data.result.filter((item) => {
            return (
              delete item._id,
              delete item.file_details,
              delete item.quantana_workspace_id,
              delete item.quantana_company_id,
              delete item.quantana_list_id
            );
          });

          localStorage.setItem("final", JSON.stringify(result));

          const COLUMNS = [];
          if (result != null) {
            for (let i = 0; i < Object.keys(result[0]).length; i++) {
              let obj = {
                Header: Object.keys(result[0])[i].toLocaleUpperCase(),
                accessor: Object.keys(result[0])[i],
              };
              COLUMNS.push(obj);
            }
          }
          console.log('COLUMNS',COLUMNS)
          console.log("result", result);
          localStorage.setItem("columns",JSON.stringify(COLUMNS))
          // setTimeout(navigate("/Table"),10000)
          setTimeout(navigate("/Table",{state:{result:result,columns:COLUMNS}}),10000);
        })
        .catch((error) => {
          console.log("error", error);
        });
    }
  };
  const navigateToLogin = () =>{
    navigate("/Login")
  }
  return (
    <>
    
      <div className="container">
      
        <div className="row">
          <Nav className="navbar navbar-expand-lg">
            <img
              src="/images/new-logo.svg"
              alt="profile"
              height={70}
              width={70}
              style={{ borderRadius: "50%" }}
              className="ps-3"
            ></img>
            <div className="navbar-nav">
              <a className="nav-link" href="#">
                Home
              </a>
              <a className="nav-link" href="#">
                Imports
              </a>
              <a className="nav-link" href="#">
                About Us
              </a>
              <a className="nav-link" href="#">
                Demo
              </a>
              <button className="free-trail-button" onClick={navigateToLogin}>Start free trial</button>
            </div>
          </Nav>
        </div>
        <div className="row">
          <div className="col-6 p-5">
            <h1 className="onboard-heading" style={{padding:"0px 50px"}}>
              Onboarding customer data shouldn’t be this <del style={{color:"#CBD5E0"}}>hard</del> easy.
            </h1>
            <p className="onboard-para">
             Get started right now by
dropping in your file here
</p>
            <div className="row">
              <div className="col-5">
              <h3 style={{paddingLeft:"50px"}}>Try demo</h3>
              </div>
              <div className="col-7">
             <img src="/images/vector-img.svg"  width="500px"
                    height="100px" style={{marginTop:"-80px"}}></img>
              </div>
           
            </div>
            
            {/* <button className="free-trail-button m-5" onClick={navigateToLogin}>Try demo</button> */}
          </div>
          <div className="col-6">
          <div className="text-center second-block">
          <Dropzone onDrop={onDrop} multiple={false}>
            {({ getRootProps, getInputProps }) => (
              <section>
                <div
                  {...getRootProps(
                    !flag ? { className: "newdropzone" } : { className: "" }
                  )}
                >
                  <img
                    src="/images/import-img.svg"
                    width="250px"
                    height="250px"
                  ></img>
                  <h5 style={{ color: "#9F7AEA" }}>Upload</h5>
                  <p>
                     or
                    drag and drop here
                  </p>
                  <input {...getInputProps()} />
                </div>
              </section>
            )}
          </Dropzone>
        </div>
          </div>
        </div>
        
        <div
          className="row centered-content"
          style={{ backgroundColor: "#181920" }}
        >
          <div className="col-6 centered-content">
            <img src="/images/files-img.svg" width={400} height={400}></img>
          </div>
          <div className="col-6 centered-content">
            <h4 style={{ color: "#9F7AEA" }}>Ingestion</h4>
            <h2 className="import-section">
              Importing All Your Data into One Place
            </h2>
            <p style={{ color: "white" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Ullamcorper varius ac tortor ut lacus integer odio. 
            </p>
            <button className="free-trail-button" onClick={navigateToLogin}>Import Now</button>
          </div>
        </div>
        <div
          className="row centered-content"
          style={{ backgroundColor: "#F7FAFC" }}
        >
          <div className="col-6 centered-content">
            <h4 style={{ color: "#718096" }}>Deduplication</h4>
            <h2 className="merge-section">
              Merging and Removing Duplicate Data
            </h2>
            <p style={{ color: "#181920" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Ullamcorper varius ac tortor ut lacus integer odio. 
            </p>
            <button className="free-trail-button" onClick={navigateToLogin}>Merge Now</button>
          </div>
          <div className="col-6 centered-content">
          <div className="text-center">
          <div className="text-center">
            <img src="/images/sheet-img.svg" width={400} height={400}></img>
            </div>
            </div>
          </div>
        </div>
        <div
          className="row centered-content"
          style={{ backgroundColor: "#9F7AEA" }}
        >
          <div className="col-6 centered-content">
          <div className="text-center">
             <img src="/images/cleanup-img.svg" width={400} height={400}></img>
             </div>
          </div>
          <div className="col-6 centered-content">
            <h4>Cleanup</h4>
            <h2 className="import-section">
              Data Cleaning with our AI engine to fix invalid row data formats
            </h2>
            <p style={{ color: "white" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Ullamcorper varius ac tortor ut lacus integer odio. 
            </p>
            <button className="cleanup-button" onClick={navigateToLogin}>Clean Up</button>
          </div>
        </div>
        <div className="row centered-content my-5">
          <div className="col-5 centered-content">
            <div
              className="row row-container"
              style={{ backgroundColor: "#9F7AEA", color: "white" }}
            >
              <p>
                <img
                  src="/images/error.svg"
                  width={40}
                  height={40}
                  className="me-2"
                ></img>
                Never miss an error again
              </p>
            </div>
            <div className="row row-container" style={{ color: "#9F7AEA" }}>
              <p>
                 
                <img
                  src="/images/customer.svg"
                  width={40}
                  height={40}
                  className="me-2"
                ></img>
                Customer data frustration ends today
              </p>
            </div>
            <div className="row row-container" style={{ color: "#9F7AEA" }}>
              <p>
                
                <img
                  src="/images/time.svg"
                  width={40}
                  height={40}
                  className="me-2"
                ></img>
                Never Spend less time in spreadsheetsmiss an error again
              </p>
            </div>
            <div className="row row-container" style={{ color: "#9F7AEA" }}>
              <p>
                
                <img
                  src="/images/system.svg"
                  width={40}
                  height={40}
                  className="me-2"
                ></img>
                Triple-checking your processes is slowing you down
              </p>
            </div>
          </div>
          <div className="col-7 centered-content">
            <h1 className="onboard-heading">Quantact lets your customer focus on using their information, not uploading data</h1>
            <br/>
            <ul>
              <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
              <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
              <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
              <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
              </ul>
          </div>
        </div>
        <div className="row py-5" 
        >
          <h3 className="text-center">User Sharing their experience</h3>
          {/* <div className="card-group p-3"> */}
          <div className="row py-5">
  <div className="card col-3 ps-3" style={{backgroundColor:"#D9D9D9"}}>
    <div className="text-center">
    <img src="/images/first-img.svg" alt="..." height={100} width={100} style={{borderRadius:"50%",marginTop: "-40px"}}/>
    </div>
    <div className="card-body text-center">
      <h5 className="card-title">Casey Collins</h5>
      <p>COO, maker Flix</p>
      <p className="card-text">TLorem ipsum dolor sit amet, consectetur adipiscing elit. Eget morbi elit in sit at tortor. Accumsan aenean venenatis, facilisi sit varius ullamcorper id adipiscing. Quis ipsum tortor quam interdum id. Posuere nulla bibendum ornare viverra dolor.</p>
     
    </div>
  </div>
  <div className="card col-3 ps-3 " style={{backgroundColor:"#EFFDD8"}}>
  <div className="text-center">
    <img src="/images/second-img.svg" alt="..." height={100} width={100} style={{borderRadius:"50%", marginTop: "-40px"}}/>
    </div>
    <div className="card-body text-center">
      <h5 className="card-title">Shirley Andrews</h5>
      <p>Rose Bailey</p>
      <p className="card-text">TLorem ipsum dolor sit amet, consectetur adipiscing elit. Eget morbi elit in sit at tortor. Accumsan aenean venenatis, facilisi sit varius ullamcorper id adipiscing. Quis ipsum tortor quam interdum id. Posuere nulla bibendum ornare viverra dolor.</p>
    </div>
  </div>
  <div className="card col-3 ps-3" style={{backgroundColor:"#D9D9D9"}}>
  <div className="text-center">
    <img src="/images/third-img.svg" alt="..." height={100} width={100} style={{borderRadius:"50%",marginTop: "-40px"}}/>
    </div>
    <div className="card-body text-center">
      <h5 className="card-title">Melanie Miller</h5>
      <p>COO, maker Flix</p>
      <p className="card-text">TLorem ipsum dolor sit amet, consectetur adipiscing elit. Eget morbi elit in sit at tortor. Accumsan aenean venenatis, facilisi sit varius ullamcorper id adipiscing. Quis ipsum tortor quam interdum id. Posuere nulla bibendum ornare viverra dolor.</p>
    </div>
  </div>
  </div>
{/* </div> */}
        </div>
        <div className="row py-5 grid-class" style={{ backgroundColor: "#9F7AEA" }}
        ><div className="py-5" >
          <h2  className="text-center pt-5" style={{color:"white"}}>Get in Touch with us</h2>
          <p className="text-center centered-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget morbi elit in sit at tortor. Accumsan aenean venenatis, facilisi sit varius ullamcorper id adipiscing. Quis ipsum tortor quam interdum id. Posuere nulla bibendum ornare viverra dolor.</p>
         <div className="text-center">
         <button className="cleanup-button invite-button" >Get my Invite</button>
         </div>
        </div></div>
        <div className="row py-5 ps-5" style={{ backgroundColor: "black" }}>
          <div className="col-3" style={{color:"white"}}>
            <h3 style={{color:"white"}}>Quantact</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget morbi elit in sit at tortor.</p>
            <img src="/images/facebook.svg" width="20px" height="20px"/> &nbsp;
            <img src="/images/instagram.svg" width="20px" height="20px"/> &nbsp;
                <img src="/images/twitter.svg" width="20px" height="20px"/> &nbsp;
                <img src="/images/youtube.svg" width="20px" height="20px"/> &nbsp;
                
          </div>
          <div className="col-3" style={{color:"white"}}>
          <h3 style={{color:"white"}}>Quick Link</h3>
         
            <p>Features</p>
            <p>Demo</p>
            <p>Privacy Policy</p>
        
          </div>
          <div className="col-3" style={{color:"white"}}>  
          <h3 style={{color:"white"}}>Resources</h3>
            <p>Home</p>
            <p>About Us</p>
            <p>Contact</p>
         </div>
          <div className="col-3" style={{color:"white"}}>
          <h3 style={{color:"white"}}>Contact</h3>
          <p> <img src="/images/call.svg" width="20px" height="20px"/> &nbsp;+968 92120341</p>
          <p> <img src="/images/mail.svg" width="20px" height="20px"/> &nbsp;quantact@quantana.com.au</p>
          </div>
        </div>
      </div>
    
    </>
  );
};
