import React, { useState, useEffect, useMemo, forwardRef, useRef } from "react";
import axios from "axios";
import { Popover,OverlayTrigger } from 'react-bootstrap';
export const DataTable = (props) => {
  var [originalData, setOriginalData] = useState([]);
  // var [tabName,setTabName] =useState("")
  var tabName = props.tab;
  var COLUMNS = props.columns;
  var columns = useMemo(() => COLUMNS, []);
  var [col, setColumns] = useState(props.columns);
  
  useEffect(() => {
    // setTabName(props.tab)
    setColumns(props.columns);
    setOriginalData(props.data);
    
    // originalData.map((r, i) => {
    //   // console.log(document.getElementById(`emailCheck__id_${i}_${tabName}`)!= null)
    //   if (document.getElementById(`header__ID`) != null) {
    //     document.getElementById(
    //       `emailCheck__id_${i}_${tabName}`
    //     ).style.display = "none";
    //     document.getElementById(`header__ID`).style.display = "none";
    //   }
    // })
  }, [props.data, props.columns]);

  var finalData = JSON.parse(localStorage.getItem("final"));
  var flag;
  if (finalData != null) {
    // for (let i = 0; i < Object.keys(finalData[0]).length; i++) {
    //   let text = Object.keys(finalData[0])[i];

    //   var result = text.toLowerCase().includes("mail");
    //   if (result == true) {
    //     flag = Object.keys(finalData[0])[i];
    //   }
    // }
  
    const re =
      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    finalData.map((r, i) => {
      // console.log(document.getElementById(`emailCheck__id_${i}_${tabName}`)!= null)
      // if (document.getElementById(`emailCheck__id_${i}_${tabName}`) != null) {
      //   document.getElementById(
      //     `emailCheck__id_${i}_${tabName}`
      //   ).style.display = "none";
      //   document.getElementById(`header__ID`).style.display = "none";
      // }

      Object.entries(r).map((item) => {
        // console.log(item[1])
        if (re.test(item[1])) {
          flag = item[0];
          return false;
        }
      });
    });

    //   var data =props.data
    //   const re =
    //   /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    //   data.map((r, i) => {
    //     console.log(tabName)
    //       if( document.getElementById(
    //         "emailCheck_" + flag + "_" + i+"_"+tabName
    //       ) != null){
    //         if (!re.test(r[flag])) {
    //           console.log("hi")
    //           // console.log( document.getElementById(
    //           //   "emailCheck_" + flag + "_" + i+"_"+tabName
    //           // ).style.backgroundColor,document.getElementById(
    //           //   "emailCheck_" + flag + "_" + i+"_"+tabName
    //           // ) )
    //           document.getElementById(
    //             "emailCheck_" + flag + "_" + i+"_"+tabName
    //           ).style.backgroundColor = "#F8A3A3";
    //     }
    //       }
    // });
  }
  const checkRegex = (cell, item) => {
   
    let re =
      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    //  console.log('fl',flag)
    if (item == flag) {
      if (!re.test(cell)) {
        return "#F8A3A3";
      } else {
        return "white";
      }
    }
  };

  const getFirstLetter = (cell) => {
    return cell.value[0].toUpperCase();
  };
  const getColorCode = () => {
    var makeColorCode = "0123456789ABCDEF";
    var code = "#";
    for (var count = 0; count < 6; count++) {
      code = code + makeColorCode[Math.floor(Math.random() * 16)];
    }
    return code;
  };
  const getColor = (cell) => {
    if (cell.value == "completed" || cell.value == "Completed") {
      return "#DBEDDB";
    } else if (cell.value == "Draft" || cell.value == "draft") {
      return "#E9E9E7";
    } else if (cell.value == "Placed" || cell.value == "placed") {
      return "#FDECC8";
    }
  };
  const handleChange = (event, column) => {
    const finalData = JSON.parse(localStorage.getItem("final"));

    const re =
      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    finalData.forEach((r, i) => {
      // console.log("r", r, i, column, flag);
      if (column === flag) {
        if (event.target.value != "Email") {
          if (
            document.getElementById("emailCheck_" + flag + "_" + i).style
              .backgroundColor == "#F8A3A3"
          ) {
            document.getElementById(
              "emailCheck_" + flag + "_" + i
            ).style.backgroundColor = "white";
          }
        }
      }

      if (column === flag) {
        // console.log(r[flag])
        if (event.target.value == "Email") {
          if (!re.test(r[flag])) {
            // if (

            //   document.getElementById(
            //     "emailCheck_" + flag + "_" + i
            //   ).style.backgroundColor == "white"
            // ) {
            // console.log( document.getElementById(
            //   "emailCheck_" + flag + "_" + i
            // ).style.backgroundColor)
            document.getElementById(
              "emailCheck_" + flag + "_" + i
            ).style.backgroundColor = "#F8A3A3";
            // }
          }
        }
      }
      // return r;
    });
    setOriginalData(finalData);
  };
  const handleCheckbox = (e) => {
    // console.log(e.target.id, flag);
    if (e.target.id === "checkbox_EMAIL") {
      if (e.target.checked == true) {
        document.getElementById("header_EMAIL").style.backgroundColor =
          "#F9E9C7";
        finalData.map((r, i) => {
          document.getElementById(
            "emailCheck_" + flag + "_" + i
          ).style.backgroundColor = "#F9E9C7";
        });
      } else {
        document.getElementById("header_EMAIL").style.backgroundColor =
          "#F7F9FC";
        finalData.map((r, i) => {
          document.getElementById(
            "emailCheck_" + flag + "_" + i
          ).style.backgroundColor = "white";
        });
      }
    }
    if (e.target.id === "checkbox_EMAIL_ADDRESS") {
      if (e.target.checked == true) {
        document.getElementById("header_EMAIL_ADDRESS").style.backgroundColor =
          "#F9E9C7";
        finalData.map((r, i) => {
          document.getElementById(
            "emailCheck_email_address_" + i
          ).style.backgroundColor = "#F9E9C7";
        });
      } else {
        document.getElementById("header_EMAIL_ADDRESS").style.backgroundColor =
          "#F7F9FC";
        finalData.map((r, i) => {
          document.getElementById(
            "emailCheck_email_address_" + i
          ).style.backgroundColor = "white";
        });
      }
    }
    setOriginalData(finalData);
  };
  const handleMerge = () => {
    // console.log(document.getElementById(`checkbox_${tabName}`).checked);
    // console.log(originalData);

    var array = { data: originalData };
    var url;
    if (window.location.hostname === "localhost") {
      url = "http://localhost:3000/csvtojson";
    } else {
      url = "https://dev.quantact.ai/backend/csvtojson";
    }
    axios
      .post(url + "/save_array", array)
      .then((res) => {
        if (res.data.status == 200) {
          axios
            .post(url + "/row_merge")
            .then((res) => {
              // console.log("finalData", finalData);
              const dupArray = JSON.parse(localStorage.getItem("dupArrayData"));
              // var flags;
              // if (finalData != null) {
              //   for (let i = 0; i < Object.keys(finalData[0]).length; i++) {
              //     let text = Object.keys(finalData[0])[i];

              //     var result = text.toLowerCase().includes("mail");
              //     if (result == true) {
              //       flags = Object.keys(finalData[0])[i];
              //     }
              //   }
              // }
              // console.log("flags", flags, dupArray);
              const results = finalData.filter(
                ({ [flag]: id1 }) =>
                  !dupArray.some(({ [flag]: id2 }) => id2 === id1)
              );
              // const results = finalData.filter(({ email: id1 }) => !dupArray.some(({ email: id2 }) => id2 === id1));

              res.data.result.forEach((item) => {
                delete item._id;
                results.push(item);
              });
              // console.log(results);
              var finalDup = [];
              props.parentCallback(finalDup, results);

              localStorage.setItem("dupArrayData", JSON.stringify([]));
              document.getElementById(`checkbox_${tabName}`).checked = false;
            })
            .catch((error) => {
              console.log(error);
            });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleIgnore = () => {
    document.getElementById(`checkbox_${tabName}`).checked = false;
    originalData.map((item, index) => {
      document.getElementById(`checkbox_${tabName}_${index}`).checked = false;
    });
  };
  const selectAllCheckbox = (e) => {
    if (e.target.checked) {
      // console.log("e", e);
      originalData.map((item, index) => {
        document.getElementById(`checkbox_${tabName}_${index}`).checked =
          e.target.checked;
        item.selected = e.target.checked;
        return item;
      });
    } else {
      originalData.map((item, index) => {
        document.getElementById(`checkbox_${tabName}_${index}`).checked =
          e.target.checked;
        item.selected = e.target.checked;
        return item;
      });
    }
    // console.log("original", originalData);
  };
  const onItemCheck = (e, value) => {
    originalData.map((item) => {
      if (value.email === item.email) {
        value.selected = e.target.checked;
      }
      return value;
    });
    // console.log(e, value, originalData);
  };
  const searchItems = (searchValue) => {
    // console.log('searchValue',searchValue)

    if (searchValue !== "") {
      const filteredData = originalData.filter((item) => {
        return Object.values(item)
          .join("")
          .toLowerCase()
          .includes(searchValue.toLowerCase());
      });
      setOriginalData(filteredData);
    } else {
      setOriginalData(props.data);
      // console.log('or',originalData)
    }
  };

  const editWithNewData = (item, data, e, val) => {
    const dataWithId = JSON.parse(localStorage.getItem("dataWithId"));
    console.log('dataWithId',dataWithId)
    var id;
    var url;
    var body = {};
    var element = document.getElementById(e.target.id);
    // console.log("ele", e,data);
    // let range = document.createRange();
    //  let   sel = window.getSelection();
    //     col = e.target.innerHTML.length;
    // range.setStart(element.childNodes[0], col);
    // range.collapse(true);
    // sel.removeAllRanges();
    // sel.addRange(range);
    // element.focus();
    // const length = element.innerText.length;
    // element.focus();
    // if(!!element.lastChild){
    //   const sel = window.getSelection();
    //   sel.collapse(element.lastChild, length);
    // }
    const selection = window.getSelection();
    const range = document.createRange();
    selection.removeAllRanges();
    range.selectNodeContents(element);
    range.collapse(false);
    selection.addRange(range);
    element.focus();
    var columnName=data;
    if (window.location.hostname === "localhost") {
      url = "http://localhost:3000/csvtojson";
    } else {
      url = "https://dev.quantact.ai/backend/csvtojson";
    }
    console.log(val)
    dataWithId.filter((i) => {
      if (i._id == val[val.length - 1]) {
        id = i._id;
      }
    });
    console.log('id',id)
    var text =  e.target.innerText 
    body = {
      contact_id: id,
      contact_details: { [columnName]:text},
    };
    axios.post(url + "/update_contact", body).then((res) => {
      var result = res.data.result;
      const filteredPeople = originalData.map((items) => {
        if (items._id === result._id) {
          items[columnName] = result[columnName];
          console.log("new value",columnName, items[columnName]);
        }
        return items;
      });
      localStorage.setItem("final", JSON.stringify(filteredPeople));
      // var finalDataAfterEdit = JSON.parse(localStorage.getItem("final"))
      setOriginalData(filteredPeople);
    });
  };
const popoverRight = (
  <Popover id="popover-positioned-right" >
    <div className="col-12 p-2">
    <div className="row">
      <div className="col-2">
    <img src="/images/profile.svg" width={60} height={60}></img>
    </div>
    <div className="col-6">
  <h6>Krishna</h6>
  <span>krishna@gmail.com</span><br>
  </br><span>9999999999</span>
   </div>
   <div className="col-4 mt-3">
    <button type="button" className="btn btn-sm btn-primary">Open profile</button>
   </div>
   </div>
   </div>
  </Popover>
);
  return (
    <>
      <div className="ms-4 d-flex">
        {/* <div>
          <input
            className="form-control"
            style={{
              marginTop: "-127px",
              width: " 370px",
              marginLeft: "410px",
            }}
            onChange={(e) => searchItems(e.target.value)}
            placeholder="Search"
          />
        </div> */}
      </div>
{/* 
      <div>
        <button className="mergebtn" onClick={handleMerge}>
          Merge
        </button>
      </div>
      <div>
        <button className="ignorebtn" onClick={handleIgnore}>
          Unselect
        </button>
      </div> */}

      <div id="myDiv" style={{ height: "75vh", overflowY: "scroll" }}>
        <table>
          <thead className="header" key="thead">
            <tr>
              <td key={Math.random()}>
                <input
                  type="checkbox"
                  id={`checkbox_${tabName}`}
                  onClick={(e) => selectAllCheckbox(e)}
                  style={{ margin: "0px 15px" }}
                />
              </td>
              {col.map((key,index) => {
                return (
                  <>
                    <th className="py-4 ps-2" id={`header_${key.Header}`} key={index}>
                      {key.Header}
                      {/* <div className="py-2">
                        <select
                          className="true dropdown"
                          onChange={(e) => handleChange(e, `${key.accessor}`)}
                          id={`dropdown_${key.Header}`}
                          aria-label="Default select example"
                        >
                          <option defaultValue="Text">Text</option>
                          <option value="First Name">First Name</option>
                          <option value="Last Name">Last Name</option>
                          <option value="Email">Email</option>
                          <option value="Phone">Phone</option>
                          <option value="Country">Country</option>
                          <option value="Date">Date</option>
                          <option value="Tags">Tags</option>
                        </select>
                        <input
                          type="checkbox"
                          id={`checkbox_${key.Header}`}
                          onClick={(e) => handleCheckbox(e)}
                          style={{ marginLeft: "20px" }}
                        />
                      </div> */}
                    </th>
                  </>
                );
              })}
            </tr>
          </thead>
          <tbody key="tbody">
            {originalData.map((val, index) => {
              if (val.selected) {
                delete val.selected;
              }
              return (
                <tr key={index}>
                  <td className="p-4" >{index+1}
                    {/* <input
                      type="checkbox"
                      id={`checkbox_${tabName}_${index}`}
                      onChange={(e) => onItemCheck(e, val)}
                      style={{ margin: "0px 15px" }}
                    /> */}
                  </td>
                  {Object.values(val).map((item, index1) => {
                    return (
                      <>
                      {/* popup---- uncomment the below one */}
                        {/* <OverlayTrigger trigger="click" placement="right" overlay={popoverRight}> */}  
     
    
                      <td key={index1}
                          onInput={(e) =>
                            editWithNewData(item,Object.keys(val)[index1], e,Object.values(val))
                          }
                          contentEditable={true}
                          suppressContentEditableWarning={true}
                          id={`emailCheck_${
                            Object.keys(val)[index1]
                          }_${index}_${tabName}`}
                          className="py-3 ps-2 table_data"
                          style={{
                            backgroundColor: checkRegex(
                              item,
                              Object.keys(val)[index1]
                            ),
                          }}
                        >
                          {item}
                          
                        </td>
                        {/* </OverlayTrigger> */}
                      </>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
};
