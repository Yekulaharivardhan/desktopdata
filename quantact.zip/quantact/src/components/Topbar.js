import React from "react";
import axios from "axios";
import {  NavDropdown } from 'react-bootstrap';
import { useNavigate, useLocation } from "react-router-dom";
import { onIdTokenChanged } from "firebase/auth";
export const Topbar = () => {
  const navigate = useNavigate();
const logOut = () =>{
 
  var token= localStorage.getItem('token')

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer '+token
  }
  var body ={
    "token": token
  }
  var url;
  console.log('result',headers,token)
  if(token != null){
    
 
  if (window.location.hostname === "localhost") {
    url = "http://localhost:3000/users";
  } else {
    url = "https://dev.quantact.ai/backend/users";
  }
  axios
    .post(url + "/signout",body,  {
      headers: headers
    },)
    .then((res) => {
      if(res.status == 200){
        localStorage.clear('token')
        localStorage.clear('refreshToken')
        navigate("/");
      }
    })
  }else{
    navigate("/");
  }
} 
    

  return (
    <div className="topbar">
      <h3 className="heading"></h3>
      {/* <img src="/images/profile-icon.jpg" alt="profile" height={50} width={50} style={{"borderRadius":"50%"}}></img> */}
      <NavDropdown
    title={
        <span>
           <img src="/images/profile-icon.jpg" alt="profile" height={50} width={50} style={{"borderRadius":"50%"}}></img>
        </span>
    }
    id='collasible-nav-dropdown'>
    <NavDropdown.Item onClick={logOut}>Logout</NavDropdown.Item>
   
</NavDropdown>

    </div>
  );
};
