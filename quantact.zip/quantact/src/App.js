import logo from "./logo.svg";
import "./App.css";
import { Sidebar } from "./components/Sidebar";
import { Topbar } from "./components/Topbar";
import { CsvImport } from "./components/CsvImport";
import { DataTable } from "./components/DataTable";
import React, { useState } from "react";
import { TabsData } from "./components/TabsData";
import { HashRouter, Route, Link, Routes } from "react-router-dom";
import {Login} from "./components/login" ;
import { useEffect } from "react";
import axios from "axios";
import { LandingPage } from "./components/landingPage";
import { SidePanel } from "./mainComponents/sidePanel";
import { IntroPanel } from "./mainComponents/introPanel";
import { TableView } from "./mainComponents/tableView";
function App() {
  useEffect(() => {
    var token =localStorage.getItem("refreshToken")
    var url;
    if(token != null){
      const body= {
        "refreshtoken": token
      }
    const intervalId = setInterval(() => {  
    
    if (window.location.hostname === "localhost") {
      url = "http://localhost:3000/users";
    } else {
      url = "https://dev.quantact.ai/backend/users";
    }
    axios
      .post(url + "/refreshtoken", body)
      .then((res) => {
        if(res.status == 200){
          console.log('res',res)
          localStorage.setItem("token",res.data.token)
        }})
    }, 600000)
    }
},)
  return (
    <>
     <HashRouter>
{/*       
     <>
    <LandingPage />
    </> */}
  
   {/* <Routes>
   <Route path="/" element={  <IntroPanel /> }>

    </Route> */}
    {/* <Route path="/Login" element={  <Login /> }>

</Route>
   <Route path="/CsvImport" element={ <>
      <div className="d-flex">
      <Sidebar/>
      <Topbar />

      </div>
   <CsvImport /> </>}>

    </Route> */}
    {/* <Route path="/TableView" element={ 
      <TableView />  }>

</Route>
    
     
       </Routes> */}
   <Routes>
   <Route path="/" element={  <LandingPage /> }>

    </Route>
    <Route path="/Login" element={  <Login /> }>

</Route>
   <Route path="/CsvImport" element={ <>
      <div className="d-flex">
      <Sidebar/>
      <Topbar />

      </div>
   <CsvImport /> </>}>

    </Route>
    <Route path="/Table" element={ 
      <TabsData />  }>

</Route>
    
     
       </Routes>
   </HashRouter>
    </>
    // <div className="App">
    //   <Sidebar />
    //   <div>
       
    //     {/* <CsvImport /> */}
    //     <TabsData/>
    //   </div>
    // </div>

    
  );
}

export default App;
