const pizzadata = [
{
  Key:"1",
  cardimgtop :"https://images.dominos.co.in/Paneer.jpg",
  cardtitle : "Paneer Paratha Pizza",
  cardtext:"Regular",
  description :"An epic fusion of paratha and pizza with melting cheese & soft paneer fillings to satisfy all your indulgent cravings"
},
{
  Key:"2",
  cardimgtop :"https://images.dominos.co.in/Keema.jpg",
  cardtitle : "Chicken Keema Paratha Pizza",
  cardtext:"",
  description :"Flavourful & meaty chicken keema paratha and goodness of cheesy pizza coming together in an epic crossover!"
},
{
  Key:"3",
  cardimgtop :"https://images.dominos.co.in/CMB1250.jpg",
  cardtitle : "Value Combo: 2 Garlic Breads",
  cardtext:"Special",
  description :"Value Combo: 2 Garlic Breads @ 99 Each"
},
{
  Key:"4",
  cardimgtop :"https://images.dominos.co.in/CMB1251.jpg",
  cardtitle : "Value Combo: 2 Choco Lava Cake",
  cardtext:"Chocolate",
  description :"Value Combo: 2 Choco Lava Cake @ 99 Each"
},
{
  Key:"5",
  cardimgtop :"https://images.dominos.co.in/new_margherita_2502.jpg",
  cardtitle : "Margherita",
  cardtext:"Regular",
  description :"Classic delight with 100% real mozzarella cheese"
},


]
export default pizzadata;
