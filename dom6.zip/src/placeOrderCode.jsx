import React, { Component } from "react";
class PlaceOrder extends Component {
  state = {};
  render() {
    return (
      <div>
        {/* <body style={{height: auto, overflow: auto,"> */}
        <div style={{ display: "block", height: "0px" }}></div>
        <noscript>
          This website requires JavaScript. To contact us, please send us an
          email at:{" "}
          <a href="mailto:guestcaredominos@jublfood.com">
            guestcaredominos@jublfood.com
          </a>
        </noscript>
        <div id="__next">
          <div className="sc-TOsTZ cnbTpD">
            <div style={{ opacity: "1" }}>
              <div className="hdr sc-caSCKo ckNtbG">
                <div className="tp-hdr">
                  <div className="logo-grp">
                    <div className="hamburger">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    <div>
                      <div className="sc-cvbbAY ccLwTT">
                        <div
                          className="side-nav"
                          style={{
                            width: "32%",
                            transition: "all 1s ease 0s",
                            top: "3.1rem",
                            right: "-50%",
                          }}
                        >
                          <div className="ovrly-child"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className="sc-cvbbAY cXLnDk">
                        <div
                          className="side-nav"
                          style={{
                            width: "24%",
                            transition: "all 1s ease 0s",
                            top: "3.1rem",
                            left: "-50%",
                          }}
                        >
                          <div className="ovrly-child"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className="sc-cvbbAY bNpetS">
                        <div
                          className="side-nav"
                          style={{
                            width: "31%",
                            transition: "all 1s ease 0s",
                            top: "3.1rem",
                            right: "-50%",
                          }}
                        >
                          <div className="ovrly-child"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className="sc-cvbbAY ctOHKt">
                        <div
                          className="side-nav"
                          style={{
                            width: "30%",
                            transition: "all 1s ease 0s",
                            top: "3.1rem",
                            left: "-50%",
                          }}
                        >
                          <div className="ovrly-child"></div>
                        </div>
                      </div>
                    </div>
                    <img
                      className="brand-logo"
                      src="/static/assets/logo_white.svg"
                      alt="dominos logo"
                    />
                  </div>
                  <div>
                    <div className="sc-cvbbAY ijYZJy">
                      <div
                        className="custom-width side-nav"
                        style={{
                          width: "32%",
                          transition: "all 1s ease 0s",
                          top: "3.1rem",
                          right: "-50%",
                        }}
                      >
                        <div className="ovrly-child"></div>
                      </div>
                    </div>
                  </div>
                  <div className="addr-prf-cnt">
                    <div className="tp--grp"></div>
                    <div className="prf-grp">
                      <img
                        src="/static/assets/avatar.svg"
                        alt="avatar"
                        data-label="profile"
                      />
                      <div className="hdr-lgn">
                        <span className="hdr-lgn-txt ellipsis">
                          Harivardhan
                        </span>
                        <span className="hdr-lgn-txt-hd">8179876715</span>
                      </div>
                      <div>
                        <div className="sc-cvbbAY cEcBPC">
                          <div
                            className="side-nav"
                            style={{
                              width: "24%",
                              transition: "all 1s ease 0s",
                              top: "-100%",
                            }}
                          >
                            <div className="ovrly-child"></div>
                          </div>
                        </div>
                      </div>
                      <div>
                        <div className="sc-cvbbAY dTHQOl">
                          <div
                            className="side-nav"
                            style={{
                              width: "32%",
                              transition: "all 1s ease 0s",
                              top: "3.1rem",
                              right: "-50%",
                            }}
                          >
                            <div className="ovrly-child"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mn-cnt">
                <div>
                  <div className="sc-cvbbAY erwkDV">
                    <div
                      className="side-nav"
                      style={{
                        width: "32%",
                        transition: "all 1s ease 0s",
                        top: "3.1rem",
                        right: "-50%",
                      }}
                    >
                      <div className="ovrly-child"></div>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="sc-cvbbAY cMobvE">
                    <div
                      className="side-nav"
                      style={{
                        width: "40%",
                        transition: "all 1s ease 0s",
                        top: "0px",
                        left: "-50%",
                      }}
                    >
                      <div className="ovrly-child"></div>
                    </div>
                  </div>
                </div>
                <div className="sc-jbKcbu jfRhRC">
                  <div className="left" style={{ minHeight: "642px" }}>
                    <div>
                      <div className="inr-lft">
                        <div className="sc-gZMcBi hDpLOF">
                          <div>
                            <div data-label="itemsList">
                              <div className="sub-hdng">
                                <span
                                  className="sub-hdng--lft"
                                  data-label="items_count"
                                >
                                  2 Items you have selected
                                </span>
                                <div className="injectStyles-sc-1jy9bcf-0 jZjFZo">
                                  <button
                                    datalabel="Explore Menu"
                                    className="btn--noStyle"
                                  >
                                    <span>Explore Menu</span>
                                  </button>
                                </div>
                                <span></span>
                              </div>
                              <div>
                                <div className="sc-iwsKbI kmFlOw">
                                  <div className="injectStyles-sc-1jy9bcf-0 bslwCH">
                                    <div
                                      className="cart-item"
                                      data-label="cart-item-entry"
                                    >
                                      <div className="flex col-dir">
                                        <div className="flex">
                                          <div className="sc-bwzfXH ehmtfw">
                                            <img
                                              className="img-wrpr__img"
                                              src="https://images.dominos.co.in/cart/Paneer.jpg"
                                            />
                                            <div className="food-icon">
                                              <div className="injectStyles-sc-1jy9bcf-0 khLfXP"></div>
                                            </div>
                                          </div>
                                          <div className="sc-htpNat lgHmxz">
                                            <div className="width100">
                                              <span className="item--ttl">
                                                Paneer Paratha Pizza
                                              </span>
                                              <span className="item--dscrptn">
                                                An epic fusion of paratha and
                                                pizza with melting cheese &amp,
                                                soft paneer fillings to satisfy
                                                all your indulgent cravings
                                              </span>
                                              <div className="item--optn">
                                                <span>Regular</span>
                                                <span>|</span>
                                                <span>
                                                  100% Wheat Thin Crust
                                                </span>
                                              </div>
                                              <div className="incr-price">
                                                <div className="price">
                                                  <div
                                                    className="price--fnl"
                                                    data-label="cart-item-price"
                                                  >
                                                    <span className="rupee">
                                                      {" "}
                                                      209.00
                                                    </span>
                                                  </div>
                                                </div>
                                                <div>
                                                  <div
                                                    className="sc-gzVnrw eeKZLn"
                                                    data-label="quantity"
                                                  >
                                                    <div
                                                      className="injectStyles-sc-1jy9bcf-0 kXLEtP"
                                                      data-label="decrease"
                                                    ></div>
                                                    <span className="cntr-val">
                                                      1
                                                    </span>
                                                    <div>
                                                      <div
                                                        className="injectStyles-sc-1jy9bcf-0 gwKvJy"
                                                        data-label="increase"
                                                      ></div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div>
                                <div className="sc-iwsKbI kmFlOw">
                                  <div className="injectStyles-sc-1jy9bcf-0 bslwCH">
                                    <div
                                      className="cart-item"
                                      data-label="cart-item-entry"
                                    >
                                      <div className="flex col-dir">
                                        <div className="flex">
                                          <div className="sc-bwzfXH ehmtfw">
                                            <img
                                              className="img-wrpr__img"
                                              src="https://images.dominos.co.in/cart/Keema.jpg"
                                            />
                                            <div className="food-icon">
                                              <div className="injectStyles-sc-1jy9bcf-0 jFdQPf"></div>
                                            </div>
                                          </div>
                                          <div className="sc-htpNat lgHmxz">
                                            <div className="width100">
                                              <span className="item--ttl">
                                                Chicken Keema Paratha Pizza
                                              </span>
                                              <span className="item--dscrptn">
                                                Flavourful &amp, meaty chicken
                                                keema paratha and goodness of
                                                cheesy pizza coming together in
                                                an epic crossover!
                                              </span>
                                              <div className="item--optn">
                                                <span>Regular</span>
                                                <span>|</span>
                                                <span>
                                                  100% Wheat Thin Crust
                                                </span>
                                              </div>
                                              <div className="incr-price">
                                                <div className="price">
                                                  <div
                                                    className="price--fnl"
                                                    data-label="cart-item-price"
                                                  >
                                                    <span className="rupee">
                                                      {" "}
                                                      249.00
                                                    </span>
                                                  </div>
                                                </div>
                                                <div>
                                                  <div
                                                    className="sc-gzVnrw eeKZLn"
                                                    data-label="quantity"
                                                  >
                                                    <div
                                                      className="injectStyles-sc-1jy9bcf-0 kXLEtP"
                                                      data-label="decrease"
                                                    ></div>
                                                    <span className="cntr-val">
                                                      1
                                                    </span>
                                                    <div>
                                                      <div
                                                        className="injectStyles-sc-1jy9bcf-0 gwKvJy"
                                                        data-label="increase"
                                                      ></div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div data-label="upsell_items">
                          <div className="sub-hdng">Complete your meal</div>
                          <div className="sc-frDJqD OxAaG">
                            <div>
                              <div
                                className="slider"
                                tabindex="0"
                                style={{
                                  boxSizing: "border-box",
                                  display: "block",
                                  height: "inherit",
                                  position: "relative",
                                  width: "100%",
                                }}
                              >
                                <div
                                  aria-live="polite"
                                  aria-atomic="true"
                                  tabindex="-1"
                                  style={{
                                    position: "absolute",
                                    left: "-10000px",
                                    top: "auto",
                                    width: "1px",
                                    height: "1px",
                                    overflow: "hidden",
                                  }}
                                >
                                  Slide 1 of 10
                                </div>
                                <div
                                  className="slider-frame"
                                  style={{
                                    boxSizing: "border-box",
                                    display: "block",
                                    height: "100%",
                                    margin: "0px",
                                    overflow: "hidden",
                                    padding: "0px",
                                    position: "relative",
                                    touchAction: "pan-y pinch-zoom",
                                    transform: "translate3d(0px, 0px, 0px)",
                                  }}
                                >
                                  <ul
                                    className="slider-list"
                                    style={{
                                      boxSizing: "border-box",
                                      cursor: "pointer",
                                      display: "block",
                                      height: "216px",
                                      margin: "0px -5px",
                                      padding: "0px",
                                      position: "relative",
                                      touchAction: "pan-y pinch-zoom",
                                      transform: "translate3d(0px, 0px, 0px)",
                                      width: "auto",
                                    }}
                                  >
                                    <li
                                      className="slider-slide slide-visible slide-current"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "0px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      tabindex="-1"
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="false"
                                        tabindex="0"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/BEV0119_1.jpg"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>Pepsi (500ml)</div>
                                            <div className="rupee">60</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide slide-visible"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "219.333px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      tabindex="-1"
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="false"
                                        tabindex="0"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/Choco_Lava.png"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>Choco Lava Cake</div>
                                            <div className="rupee">109</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide slide-visible"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "438.667px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      tabindex="-1"
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="false"
                                        tabindex="0"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/Crinkle_Fries.png"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>Crinkle Fries</div>
                                            <div className="rupee">69</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide slide-visible"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "658px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      tabindex="-1"
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="false"
                                        tabindex="0"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/ALPHONSO.jpg"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>
                                              B Natural Alphonsos from Ratnagiri
                                              (300 ml)
                                            </div>
                                            <div className="rupee">70</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide slide-visible"
                                      tabindex="-1"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "877.333px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="false"
                                        tabindex="0"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/crunchy_strips.png"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>Crunchy Strips</div>
                                            <div className="rupee">69</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide slide-visible"
                                      tabindex="-1"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "1096.67px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="false"
                                        tabindex="0"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/PINKGUAVA.jpg"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>
                                              B Natural Pink Guavas from Dakshin
                                              India (300 ml)
                                            </div>
                                            <div className="rupee">70</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "1316px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      inert=""
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="true"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/MIXEDFRUIT.jpg"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>
                                              B Natural Mixed Fruit from
                                              Himalayas (300 ml)
                                            </div>
                                            <div className="rupee">70</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "1535.33px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      inert=""
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="true"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/Garlic_bread.png"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>Garlic Breadsticks</div>
                                            <div className="rupee">109</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "1754.67px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      inert=""
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="true"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/new_jalapeno.png"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>Cheesy Jalapeno Dip</div>
                                            <div className="rupee">30</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                    <li
                                      className="slider-slide"
                                      style={{
                                        boxSizing: "border-box",
                                        display: "inline-block",
                                        height: "216px",
                                        left: "1974px",
                                        listStyleType: "none",
                                        margin: "auto 5px",
                                        position: "absolute",
                                        top: "0px",
                                        transform: "scale(1)",
                                        transition: "transform 0.4s linear 0s",
                                        verticalAlign: "top",
                                        width: "209.333px",
                                      }}
                                      aria-hidden="true"
                                      inert=""
                                    >
                                      <div
                                        className="injectStyles-sc-1jy9bcf-0 dcociV"
                                        aria-hidden="true"
                                      >
                                        <div className="upsell__img-wrpr">
                                          <img
                                            src="https://images.dominos.co.in/cart/Brownie_Fantasy.png"
                                            defaultimage="/static/assets/upsell_placeholder.png"
                                            className="upsell__img"
                                          />
                                          <div className="injectStyles-sc-1jy9bcf-0 flektL"></div>
                                          <div className="injectStyles-sc-1jy9bcf-0 dPGuMz"></div>
                                          <div className="upsell__data">
                                            <div>Brownie Fantasy</div>
                                            <div className="rupee">79</div>
                                          </div>
                                        </div>
                                        <div className="upsell__add-cntnr">
                                          <div className="upsell__add">Add</div>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                                <div
                                  className="slider-control-centerleft"
                                  style={{
                                    position: "absolute",
                                    top: "50%",
                                    left: "0px",
                                    transform: "translateY(-50%)",
                                  }}
                                >
                                  <img
                                    srcSet="https://pizzaonline.dominos.co.inhttps://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png 1x, https://pizzaonline.dominos.co.inhttps://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png@2x.png 2x, https://pizzaonline.dominos.co.inhttps://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png@3x.png 3x"
                                    src="https://pizzaonline.dominos.co.inhttps://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png"
                                    alt="Arrow Left"
                                    className="control-carousel rtt-crsl-img"
                                  />
                                </div>
                                <div
                                  className="slider-control-centerright"
                                  style={{
                                    position: "absolute",
                                    top: "50%",
                                    right: "0px",
                                    transform: "translateY(-50%)",
                                  }}
                                >
                                  <img
                                    srcSet="https://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png 1x, https://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png@2x.png 2x, https://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png@3x.png 3x"
                                    src="https://pizzaonline.dominos.co.in/static/assets/slider-arrow-right.png"
                                    alt="Arrow Right"
                                    className="control-carousel"
                                  />
                                </div>
                                {/* { <style type="text/css">
                                                        .slider-slide > img {
                                                            width: "100%",
                                                            display: "block",
                                                        }
                                                        .slider-slide > img:focus {
                                                            margin: auto,
                                                        }
                                                    </style> } */}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="right">
                    <div className="inr-rght">
                      <div className="sc-kgAjT dZTvdM">
                        <span className="hdng" data-label="delivery_address">
                          Choose a delivery address
                        </span>
                        <div className="injectStyles-sc-1jy9bcf-0 cpLABG">
                          <div className="adrs-cntr">
                            <div className="icon-cnt">
                              <div className="injectStyles-sc-1jy9bcf-0 bLFVnP"></div>
                            </div>
                            <div className="adrs-wrpr">
                              <div className="address-cont">
                                <p className="current-heading">
                                  Current Address
                                </p>
                                <p className="current-address">HYDERABAD</p>
                              </div>
                              <div className="edt-adrs">Edit Address</div>
                            </div>
                            <div className="injectStyles-sc-1jy9bcf-0 kWuABf">
                              <button className="btn--grn">
                                <span>Change</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div>
                        <div className="sc-cvbbAY ijYZJy">
                          <div
                            className="custom-width side-nav"
                            style={{
                              width: "32%",
                              transition: "all 1s ease 0s",
                              top: "3.1rem",
                              right: "-50%",
                            }}
                          >
                            <div className="ovrly-child"></div>
                          </div>
                        </div>
                      </div>
                      <div>
                        <div className="sc-cvbbAY ezzMP">
                          <div
                            className="side-nav"
                            style={{
                              width: "30%",
                              transition: "all 1s ease 0s",
                              top: "3.1rem",
                              right: "-50%",
                            }}
                          >
                            <div className="ovrly-child"></div>
                          </div>
                        </div>
                      </div>
                      <div>
                        <div className="sc-cvbbAY ezzMP">
                          <div
                            className="side-nav"
                            style={{
                              width: "30%",
                              transition: "all 1s ease 0s",
                              top: "3.1rem",
                              right: "-50%",
                            }}
                          >
                            <div className="ovrly-child"></div>
                          </div>
                        </div>
                      </div>
                      <span className="sub-hdng-offers">Offers</span>
                      <div
                        className="injectStyles-sc-1jy9bcf-0 hkXrqZ"
                        data-label="offers"
                      >
                        <div className="offr-strp-icn injectStyles-sc-1jy9bcf-0 hytckB"></div>
                        <div className="offr-strp-txt">
                          <span className="offr-strp-txt__uppr">
                            Select offer / Apply coupon
                          </span>
                          <span className="offr-strp-txt__lwr">
                            Get discount with your order
                          </span>
                        </div>
                        <div className="offr-strp-icn__rght injectStyles-sc-1jy9bcf-0 ePZBKw"></div>
                      </div>
                      <div className="sc-hMqMXs dtMuXa">
                        <span
                          className="sub-hdng itms"
                          data-label="items_count"
                        >
                          Price Details
                        </span>
                        <div className="injectStyles-sc-1jy9bcf-0 gatcFE">
                          <div className="sc-eNQAEJ hetvrx">
                            <div className="txt--wrpr">
                              <span
                                className="sc-fjdhpX ickrvO"
                                data-label="Sub Total"
                              >
                                Sub Total
                              </span>
                              <span className="sc-jzJRlG gDSIXD">
                                <span className="rupee">458.00</span>
                              </span>
                            </div>
                            <div className="txt--wrpr">
                              <span
                                className="sc-fjdhpX ickrvO"
                                data-label="Discount"
                              >
                                Discount
                              </span>
                              <span className="sc-jzJRlG gDSIXD">-</span>
                            </div>
                            <div className="txt--wrpr marginBottom">
                              <span
                                className="sc-fjdhpX ickrvO"
                                data-label="Taxes and Charges"
                              >
                                Taxes and Charges
                                <div>
                                  <div className="sc-kgoBCf dERjRQ">
                                    <b>i</b>
                                  </div>
                                </div>
                              </span>
                              <span className="sc-jzJRlG gDSIXD">
                                <span className="rupee">57.90</span>
                              </span>
                            </div>
                            <div className="sc-chPdSV jXxXLA"></div>
                            <div className="txt--wrpr marginTop">
                              <span
                                className="txt--bold sc-fjdhpX ickrvO"
                                data-label="Grand Total"
                              >
                                Grand Total
                              </span>
                              <span className="txt--bold txt--bggr sc-jzJRlG gDSIXD">
                                <span className="rupee">515.90</span>
                              </span>
                            </div>
                            <div className="sc-chPdSV jXxXLA"></div>
                            <div className="injectStyles-sc-1jy9bcf-0 fNOYBs">
                              <button data-label="Place Order">
                                <span>Place Order</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="sc-cHGsZl cZfgUK">
                <div className="ftr-wrpr">
                  <div className="ftr-lft">
                    <div className="ftr-img">
                      <img
                        className="brand-logo"
                        src="https://pizzaonline.dominos.co.in/static/assets/logo_white.svg"
                        alt="dominos logo"
                      />
                    </div>
                    <div className="ftr-cntnt">
                      <ul className="ftr-lnk">
                        <li className="lst-hdr">Disclaimer</li>
                      </ul>
                      <ul className="ftr-lnk">
                        <li className="lst-hdr">Privacy Policy</li>
                      </ul>
                      <ul className="ftr-lnk">
                        <li className="lst-hdr">Faq</li>
                      </ul>
                      <ul className="ftr-lnk">
                        <li className="lst-hdr">Terms &amp, Conditions</li>
                      </ul>
                      <ul className="ftr-lnk">
                        <li className="lst-hdr">Feedback</li>
                      </ul>
                    </div>
                  </div>
                  <div className="ftr-rgt">
                    <div>DOWNLOAD APP</div>
                    <div className="icn">
                      <img
                        alt="google_play_store"
                        src="https://pizzaonline.dominos.co.in/static/assets/play_store.png"
                        srcSet="https://pizzaonline.dominos.co.in/static/assets/play_store.png 1x, https://pizzaonline.dominos.co.in/static/assets/play_store@2x.png 2x, https://pizzaonline.dominos.co.in/static/assets/play_store@3x.png 3x"
                      />
                      <img
                        alt="app_store"
                        src="https://pizzaonline.dominos.co.in/static/assets/play_store.png"
                        srcSet="/static/assets/app_store.png 1x, /static/assets/app_store@2x.png 2x, /static/assets/app_store@3x.png 3x"
                      />
                    </div>
                  </div>
                </div>
                <div>
                  <div className="sc-cvbbAY cXLnDk">
                    <div
                      className="side-nav"
                      style={{
                        width: "24%",
                        transition: "all 1s ease 0s",
                        top: "3.1rem",
                        left: "-50%",
                      }}
                    >
                      <div className="ovrly-child"></div>
                    </div>
                  </div>
                </div>
                <div className="copyright">
                  All Rights Reserved. Copyright © Jubilant FoodWorks Ltd.
                </div>
              </div>
            </div>
            <div className="online-strip">Internet connection Lost</div>
          </div>
        </div>
        <div id="__next-error"></div>
      </div>
    );
  }
}

export default PlaceOrder;
