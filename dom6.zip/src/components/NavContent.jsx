import React from "react";
import "./NavContent.css";

const NavContent = () => {
  return (
    <div>
      <div className="tp-hdr">
        <div className="logo-group">
          <div className="hamburger">
            <span></span>
            <span></span>
            <span></span>
          </div>
          <div>
            <div className="SideBarContainer sbc_cls">
              <div className="side-nav">
                <div className="ovrly-child"></div>
              </div>
            </div>
          </div>
          <div>
            <div className="SideBarContainer jLtAra">
              <div className="side-nav">
                <div className="ovrly-child"></div>
              </div>
            </div>
          </div>
          <div>
            <div className="SideBarContainer kDMxJu">
              <div className="side-nav">
                <div className="ovrly-child"></div>
              </div>
            </div>
          </div>
          <div>
            <div className="SideBarContainer kdpPFO">
              <div className="side-nav">
                <div className="ovrly-child"></div>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div className="SideBarContainer gmDyxZ">
            <div className="custom-width side-nav">
              <div className="ovrly-child"></div>
            </div>
          </div>
        </div>
        <div className="addr-prf-cnt">
          <div className="tp--grp">
            <div className="sc-gzVnrw nav_Bar_right_Container">
              <div className="sc-bZQynM nav_Bar_right_Container_subcls">
                <label className=" container" data-label="Order_Type_Deliver">
                  <span>Delivery</span>
                  <input type="radio" readOnly="" name="deliveryType" />
                  <span className="checkmark">
                    <span className="checked"></span>
                  </span>
                </label>
              </div>
              {/* <div className="sc-bZQynM nav_Bar_right_Container_subcls">
                <label
                  className="non--slctd container"
                  data-label="Order_Type_Pickup"
                >
                  <span>Pick Up/Dine-in</span>
                  <input type="radio" readOnly="" name="deliveryType" />
                  <span className="checkmark"></span>
                </label>
              </div> */}
            </div>
          </div>
          <div className="slct-lctn">
            <div className="slct-lctn-cnt">
              <img src="/static/assets/icons/location_white.png" alt="" />
              <div className="slct-lctn-txt selected_location-txt">HYDERABAD</div>
            </div>
            <div className="injectStyles-src bdMFpM"></div>
          </div>
          <div className="prf-grp">
            <img
              src="/static/assets/avatar.svg"
              alt="avatar"
              data-label="profile"
            />
            <div data-label="my-account" className="prf-grp-txt">
              <div>MY ACCOUNT</div>
              <div className="prf-grp-txt-hd">Login | Signup</div>
            </div>
            <div>
              <div className="SideBarContainer sbc_Divclass">
                <div className="side-nav">
                  <div className="ovrly-child"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavContent;
