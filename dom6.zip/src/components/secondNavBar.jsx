import React from "react";
// import { NavLink } from "react-router-dom";
import "./secondNavBar.css";
import Counter from "./counter";
import "./card.css";

const Image = "https://images.dominos.co.in/Paneer.jpg";
const img2 = "https://images.dominos.co.in/4625-CMB1211.jpg";
const img3 = "https://images.dominos.co.in/CMB1250.jpg";
const img4 = "https://images.dominos.co.in/PIZ5158_1.jpg";
const img5 = "https://images.dominos.co.in/PIZ0171.jpg";
const img6 = "https://images.dominos.co.in/PIZ5160_1.jpg";

const SecondNavBar = () => {
  return (
    <div>
      <div className="sc-htpNat esboMF">
        <nav id="navbar-example2" className="navbar navbar bg">
          <div className="mn-hdr hide" data-label="Everyday Value">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-1"
            >
              EVERYDAY VALUE
            </a>
          </div>

          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-2"
            >
              BESTSELLERS
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-3"
            >
              NEW LAUNCHES
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-4"
            >
              PARATHA PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-5"
            >
              VEG PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-6"
            >
              BEVERAGES
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-7"
            >
              NON-VEG PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-8"
            >
              CHICKEN LOVERS PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-9"
            >
              SPECIALITY CHICKEN
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-10"
            >
              SIDES
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-11"
            >
              PIZZA MANIA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-12"
            >
              MEAL FOR 1
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-13"
            >
              MEAL FOR 2
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-14"
            >
              MEAL FOR 4
            </a>
          </div>
          <div className="mn-hdr hide">
            <a
              className="list-group-item list-group-item-action"
              href="#list-item-15"
            >
              PARTY COMBOS
            </a>
          </div>
          <div className="mn-hdr hide"></div>
        </nav>
      </div>

      <div
        data-spy="scroll"
        data-target="#list-example"
        data-offset="0"
        className="scrollspy-example"
      >
        <h4 id="list-item-1" style={{ marginTop: "80px" }}>
          EVERYDAY VALUE
        </h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>
        <h4 id="list-item-2">BEST SELLERS</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-3">NEW LAUNCHES</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>
        <h4 id="list-item-4">PARATHA PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>
        <h4 id="list-item-5">VEG PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-6">BEVERAGES</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-7">NON-VEG PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-8">CHICKEN LOVERS PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-9">SPECIALITY CHICKEN</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-10">PARTY COMBOS</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>
        <h4 id="list-item-12">MEAL FOR 1</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-13">MEAL FOR 2</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>

        <h4 id="list-item-14">MEAL FOR 4</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter />
            </div>
          </div>
        </div>
      </div>

      <div className="ref">
        <div className="menu-hr"></div>
        <div className="cat-bar">
          <div className="menu-catname ">EVERYDAY VALUE</div>
        </div>
      </div>
    </div>

    // style="margin-top: -3em; padding-left: 5rem; padding-right: 5rem; box-shadow: rgb(210, 221, 233) 5px 5px 5px; transition: all 1s ease-in-out 0s;"

    // <React.Fragment>
    //   <div className="second-Navbar-Content" style={{ paddingLeft: "5rem", paddingRight: "5rem", boxShadow: "rgb(210, 221, 233) 5px 5px 5px", transition: "all 1s ease-in-out 0s"}}>
    //     <nav className="navbar navbar-expand-lg navbar-light bg-light">
    //       <li className="nav-item active">
    //         <NavLink className="nav-link" to="#">
    //           EVERYDAY VALUE <span className="sr-only">(current)</span>
    //         </NavLink>
    //       </li>
    //       <button
    //         className="navbar-toggler"
    //         type="button"
    //         data-toggle="collapse"
    //         data-target="#navbarNav"
    //         aria-controls="navbarNav"
    //         aria-expanded="false"
    //         aria-label="Toggle navigation"
    //       >
    //         <span className="navbar-toggler-icon"></span>
    //       </button>
    //       <div className="collapse navbar-collapse" id="navbarNav">
    //         <ul className="navbar-nav">
    //           <li className="nav-item active">
    //             <NavLink className="nav-link" to="#">
    //               BESTSELLERS <span className="sr-only">(current)</span>
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               NEW LAUNCHES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PARATHA PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               VEG PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               BEVERAGES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               NON-VEG PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               CHICKEN LOVERS PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               SPECIALITY CHICKEN
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               SIDES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PIZZA MANIA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 1
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 2
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 3
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 4
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PARTY COMBOS
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               DESSERT
    //             </NavLink>
    //           </li>
    //         </ul>
    //       </div>
    //     </nav>
    //   </div>

    /* <div className="sc-htpNat esboMF">
        <div className="mn-hdr hide" data-label="Everyday Value">
          <span>EVERYDAY VALUE</span>
        </div>
        <div className="mn-hdr active" data-label="Bestsellers">
          <span>BESTSELLERS</span>
        </div>
        <div className="mn-hdr hide" data-label="New Launches">
          <span>NEW LAUNCHES</span>
        </div>
        <div className="mn-hdr hide" data-label="Paratha Pizza">
          <span>PARATHA PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Veg Pizza">
          <span>VEG PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Beverages">
          <span>BEVERAGES</span>
        </div>
        <div className="mn-hdr hide" data-label="Non-Veg Pizza">
          <span>NON-VEG PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Chicken Lovers Pizza">
          <span>CHICKEN LOVERS PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Speciality Chicken">
          <span>SPECIALITY CHICKEN</span>
        </div>
        <div className="mn-hdr hide" data-label="Sides">
          <span>SIDES</span>
        </div>
        <div className="mn-hdr hide" data-label="Pizza Mania">
          <span>PIZZA MANIA</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 1">
          <span>MEAL FOR 1</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 2">
          <span>MEAL FOR 2</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 4">
          <span>MEAL FOR 4</span>
        </div>
        <div className="mn-hdr hide" data-label="Party Combos">
          <span>PARTY COMBOS</span>
        </div>
        <div className="mn-hdr hide" data-label="Dessert">
          <span>DESSERT</span>
        </div>
      </div> }
    </React.Fragment>*/
  );
};

export default SecondNavBar;
