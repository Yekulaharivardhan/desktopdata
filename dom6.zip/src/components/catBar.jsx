import React from "react";
import "./catBar.css";
const Catbar = () => {
  return (
    <div className="cat-bar">
      <div className="menu-catname ">BESTSELLERS</div>
    </div>
  );
};

export default Catbar;
