import React, { Component } from "react";
// import Navbar from "./components/Navbar";
import Cards from "./components/card";
// import NavContent from "./components/NavContent";
import Catbar from "./components/catBar";
import SecondNavBar from "./components/secondNavBar";
import CartStatusimg from "./components/cartStatus";
import NavBarTwo from "./components/navBarTwo";
// import LoginPage from "./logincomponents/Login";
import BsModal from "./components/modal";

class App extends Component {
  render() {
    return (
      <React.StrictMode>
        <BsModal />
        <main className="containertwo">
          <NavBarTwo />

          <SecondNavBar />
          {/* <Counter/> */}
          <CartStatusimg />
          {/* <NavContent /> */}
          <Catbar />
          {/* <LoginPage/> */}

          <Cards />
        </main>
      </React.StrictMode>
    );
  }
}

export default App;
