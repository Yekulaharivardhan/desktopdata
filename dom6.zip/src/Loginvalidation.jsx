// import { Component } from "react";

// class LoginValidation extends Component {
//   state = {};
//   render() {
//     function validate() {
//       var mobileNumber = document.getElementById("mobilenumber").value;

//       if (mobileNumber.value.length > 10 && mobileNumber.value.match(/[0-9]/)) {
//         alert("Success");
//       } else {
//         alert("Please check Mobile Number");
//       }
//     }
//     return;
//   }
// }

// export default LoginValidation;
